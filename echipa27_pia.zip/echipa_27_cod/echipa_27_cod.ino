#include <WiFi.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// Setări WiFi
const char* ssid = "Galaxy A805F31";
const char* password = "Imiplacesamananc";

// Pini
#define ONE_WIRE_BUS 23
const int ledPini[7] = {15, 2, 0, 4, 17, 18, 19};

OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);
WiFiServer server(80);

void setup() {
  Serial.begin(115200);
  sensors.begin();
  for (int i = 0; i < 7; i++) pinMode(ledPini[i], OUTPUT);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println("\nConectat! Adresa IP: ");
  Serial.println(WiFi.localIP());
  server.begin();
}

void loop() {
  WiFiClient client = server.available();
  if (client) {
    sensors.requestTemperatures();
    float t = sensors.getTempCByIndex(0);
    
    // Logica pentru numărul de LED-uri (n) folosind IF-uri clasice
    int n = 0;
    
    if (t < 18) {
      n = 1;
    } else if (t < 20) {
      n = 2;
    } else if (t < 22) {
      n = 3;
    } else if (t < 24) {
      n = 4;
    } else if (t < 26) {
      n = 5;
    } else if (t < 28) {
      n = 6;
    } else {
      n = 7; // Pentru 28 grade sau mai mult
    }

    // Aprindem LED-urile corespunzătoare
    for (int i = 0; i < 7; i++) {
      if (i < n) {
        digitalWrite(ledPini[i], HIGH);
      } else {
        digitalWrite(ledPini[i], LOW);
      }
    }

    // Trimitere pagină HTML
    client.println("HTTP/1.1 200 OK");
    client.println("Content-Type: text/html");
    client.println("Connection: close");
    client.println("Refresh: 2");
    client.println();
    client.println("<html><body><h1>Temperatura: " + String(t) + " &deg;C</h1>");
    client.println("<p>LED-uri aprinse: " + String(n) + "/7</p></body></html>");
    client.stop();
  }
}